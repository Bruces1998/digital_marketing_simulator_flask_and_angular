import { Component, OnInit, AfterViewInit } from '@angular/core';
import { EventEmitter, Input, Output } from '@angular/core';
import * as Feather from 'feather-icons';
import * as go from 'gojs';

@Component({
  selector: 'app-element-editor',
  templateUrl: './element-editor.component.html',
  styleUrls: ['./element-editor.component.scss']
})
export class ElementEditorComponent implements OnInit {

  public _selectedNode: go.Node;
  public data = {
    key: null,
    elem: null,
    elemName: null
  };

  @Input()
  public model: go.Model;

  @Output()
  public onFormChange: EventEmitter<any> = new EventEmitter<any>();

  @Input()
  get selectedNode() {return this._selectedNode;}
  set selectedNode(node: go.Node){
    if(node){
      this._selectedNode = node;
      this.data.key = this._selectedNode.data.key;
      this.data.elem = this._selectedNode.data.elem;
      this.data.elemName = this._selectedNode.data.elemName;
    } else {
      this._selectedNode = null;
      this.data.key = null;
      this.data.elem = null;
      this.data.elemName = null;
    }
  }

  constructor() { }

  ngOnInit(): void {
  }

  ngAfterViewInit() {
    Feather.replace();
  }
  
  public onCommitForm() {
    this.onFormChange.emit(this.data);
  }

}
