import { Component, NgZone, OnInit, AfterViewInit } from '@angular/core';
import { NextConfig } from '../../../app-config';
import { Location } from '@angular/common';
import { ChangeDetectorRef, ViewChild, ViewEncapsulation } from '@angular/core'
import * as Feather from 'feather-icons';
import * as go from 'gojs';
import { DataSyncService, DiagramComponent, PaletteComponent } from 'gojs-angular';
import * as _ from 'lodash';
import { FormBuilder } from '@angular/forms';
import { HttpClient } from '@angular/common/http'


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class AdminComponent implements OnInit {
  public nextConfig: any;
  public navCollapsed: boolean;
  public navCollapsedMob: boolean;
  public windowWidth: number;
  @ViewChild('myDiagram', { static: true }) public myDiagramComponent: DiagramComponent;
  @ViewChild('myPalette', { static: true }) public myPaletteComponent: PaletteComponent;
  mainModalMax : boolean = false;
  newElemFormGroup;
  hidePalette : boolean = false;
  hideElemForm : boolean = false;
  showGrid : boolean = false;
  enableAlign : boolean = false;
  overviewPos : number = 1;

  paletteData: JSON;

  template = [
    { id:1, name:'Facebook Ad', img: '../../assets/imgs/Template1.JPG'},
  ]

  icons =[
    {key: 1, name: 'clock'},
    {key: 2, name: 'edit'},
    {key: 3, name: 'grid'},
    {key: 4, name: 'align-justify'},
    {key: 5, name: 'zoom-in'},
    {key: 6, name: 'zoom-out'},
    {key: 7, name: 'rotate-ccw'},
    {key: 8, name: 'rotate-cw'},
    {key: 9, name: 'copy'},
    {key: 10, name: 'clipboard'},
    {key: 11, name: 'trash'},
    {key: 12, name: 'clock'},
    {key: 13, name: 'square'},
    {key: 14, name: 'download'},
    {key: 15, name: 'archive'},
    {key: 16, name: 'plus'}
  ] ;

  // ********* DIAGRAM **********
  // initialize diagram / templates
  maximize(){
    console.log(this.mainModalMax)
    this.mainModalMax = !this.mainModalMax;
  }

  getPaletteData(){
    this.http.get("http://127.0.0.1:8000/send").subscribe(data => {
    this.paletteData = data as JSON;
    console.log(this.paletteData['data']);
    this.paletteNodeData = this.paletteData['data'];
  }
    )
  }

  public initDiagram(): go.Diagram {

    const $ = go.GraphObject.make;
    const dia = $(go.Diagram, {
      'undoManager.isEnabled': true,
      model: $(go.GraphLinksModel,
        {
          linkToPortIdProperty: 'toPort',
          linkFromPortIdProperty: 'fromPort',
          linkKeyProperty: 'key' // IMPORTANT! must be defined for merges and data sync when using GraphLinksModel
        }
      )
    });

    dia.commandHandler.archetypeGroupData = { key: 'Group', isGroup: true };

    dia.nodeTemplate =
      $(go.Node, "Vertical",
        $(go.Picture, {width: 85, height: 85}, new go.Binding("source", "elem"),
        {portId:"", fromLinkable: true, toLinkable: true, cursor:'pointer'}),
        $(go.TextBlock, {font:'14pt Sen, sans-serif',margin:2, editable:true}, new go.Binding("text","elemName")),
        {
          selectionAdornmentTemplate:
            $(go.Adornment, "Auto",
              $(go.Shape, "RoundedRectangle",
                { fill: null, stroke: "rgba(0, 172, 240)", strokeWidth: 2.5 },
                new go.Binding("stroke", "color")),
              $(go.Placeholder)
            )  // end Adornment
        }
        
      )

    dia.linkTemplate =
    $(go.Link,
      $(go.Shape, { strokeWidth: 1 }),
      $(go.Shape, { toArrow: "Standard" }),
      {
        selectionAdornmentTemplate:
          $(go.Adornment,
            $(go.Shape,
              { isPanelMain: true, stroke: "rgb(0, 172, 240)", strokeWidth: 2 }),
            // $(go.Shape,
            //   { toArrow: "Standard", fill: "rgb(0, 172, 240)", stroke: null, scale:1.4 })
          )  // end Adornment
      }
    );
    return dia;
    // rgb(0, 172, 240)
  }

  public diagramNodeData: Array<go.ObjectData> = [];
  public diagramLinkData: Array<go.ObjectData> = [];
  public diagramDivClassName: string = 'myDiagramDiv';
  public diagramModelData = { prop: 'value' };
  public skipsDiagramUpdate = false;
  
  // When the diagram model changes, update app data to reflect those changes
  public diagramModelChange = function(changes: go.IncrementalData) {
    // when setting state here, be sure to set skipsDiagramUpdate: true since GoJS already has this update
    // (since this is a GoJS model changed listener event function)
    // this way, we don't log an unneeded transaction in the Diagram's undoManager history
    this.skipsDiagramUpdate = true;

    this.diagramNodeData = DataSyncService.syncNodeData(changes, this.diagramNodeData);
    this.diagramLinkData = DataSyncService.syncLinkData(changes, this.diagramLinkData);
    this.diagramModelData = DataSyncService.syncModelData(changes, this.diagramModelData);
  };

  // ******** PALETTE **********
  public initPalette(): go.Palette {
    const $ = go.GraphObject.make;
    const palette = $(go.Palette);

    // define the Node template
    palette.nodeTemplate =
      $(go.Node, "Vertical",
        $(go.Picture, {width: 55, height:55, margin: 5}, new go.Binding("source", "elem")),
        $(go.TextBlock, {font:'10pt Sen, sans-serif', margin: 2}, new go.Binding("text", "elemName")),
        {
          selectionAdornmentTemplate:
            $(go.Adornment, "Auto",
              $(go.Shape, "RoundedRectangle",
                { fill: null, stroke: "rgba(0, 172, 240)", strokeWidth: 2.5 },
                new go.Binding("stroke", "color")),
              $(go.Placeholder)
            )  // end Adornment
        }
      );

    palette.model = $(go.GraphLinksModel,
      {
        linkKeyProperty: 'key'  // IMPORTANT! must be defined for merges and data sync when using GraphLinksModel
      });

    return palette;
  }

  public paletteNodeData: Array<go.ObjectData> = [];

  public paletteLinkData: Array<go.ObjectData> = [];
  public paletteModelData = { prop: 'val' };
  public paletteDivClassName = 'myPaletteDiv';
  public paletteModelChange = function(changes: go.IncrementalData) {
    this.paletteNodeData = DataSyncService.syncNodeData(changes, this.paletteNodeData);
    this.paletteLinkData = DataSyncService.syncLinkData(changes, this.paletteLinkData);
    this.paletteModelData = DataSyncService.syncModelData(changes, this.paletteModelData);
  };

  constructor( private zone: NgZone, private location: Location, private cdr: ChangeDetectorRef, private formBuilder: FormBuilder, private http: HttpClient) {
    this.nextConfig = NextConfig.config;
    let currentURL = this.location.path();
    const baseHerf = this.location['_baseHref'];
    if (baseHerf) {
      currentURL = baseHerf + this.location.path();
    }

    this.windowWidth = window.innerWidth;

    if (currentURL === baseHerf + '/layout/collapse-menu'
      || currentURL === baseHerf + '/layout/box'
      || (this.windowWidth >= 992 && this.windowWidth <= 1024)) {
      this.nextConfig.collapseMenu = true;
    }

    this.navCollapsed = (this.windowWidth >= 992) ? this.nextConfig.collapseMenu : false;
    this.navCollapsedMob = false;

    this.newElemFormGroup = this.formBuilder.group({
      newElemTitle: '',
      newElemImage: '',
    });
    this.getPaletteData()
  }

  // ********** OVERVIEW ***********
  public oDivClassName = 'myOverviewDiv';
  public initOverview(): go.Overview {
    const $ = go.GraphObject.make;
    const overview = $(go.Overview);
    return overview;
  }
  public observedDiagram = null;

  // currently selected node; for inspector
  public selectedNode: go.Node | null = null;



  // ******* TOOLBAR *********
  paletteToggle() {
    this.hidePalette = !this.hidePalette;
  }

  elemFormToggle() {
    this.hideElemForm = !this.hideElemForm;
  }

  gridToggle() {
    this.showGrid = !this.showGrid;
    if (this.myDiagramComponent && this.myDiagramComponent.diagram instanceof go.Diagram) {
      this.myDiagramComponent.diagram.grid.visible = this.showGrid;
    }
  }

  alignToggle(){
    this.enableAlign = !this.enableAlign;
    if (this.myDiagramComponent && this.myDiagramComponent.diagram instanceof go.Diagram) {
      this.myDiagramComponent.diagram.grid.visible = this.enableAlign;
      this.myDiagramComponent.diagram.toolManager.draggingTool.isGridSnapEnabled = this.enableAlign;
    }
  }

  zoomIn(){
    this.myDiagramComponent.diagram.commandHandler.increaseZoom();
  }

  zoomOut(){
    this.myDiagramComponent.diagram.commandHandler.decreaseZoom();
  }

  undoChanges(){
    this.myDiagramComponent.diagram.commandHandler.undo();
  }

  redoChanges(){
    this.myDiagramComponent.diagram.commandHandler.redo();
  }

  copySelect(){
    this.myDiagramComponent.diagram.commandHandler.copySelection();
  }
  
  pasteSelect(){
    this.myDiagramComponent.diagram.commandHandler.pasteSelection();
  }
  
  deleteSelect(){
    this.myDiagramComponent.diagram.commandHandler.deleteSelection();
  }
  
  clearCanvas(){
    var confirmation=confirm('Are you sure you want to Clear the Canvas?');
    if(confirmation){
      this.myDiagramComponent.diagram.clear();
    }
  }

  overviewPositionChange(){
    if( this.overviewPos == 4){
      this.overviewPos = 1;
    }
    else{
      this.overviewPos++;
      
    }
  }

  ngOnInit() {
    if (this.windowWidth < 992) {
      this.nextConfig.layout = 'vertical';
      setTimeout(() => {
        document.querySelector('.pcoded-navbar').classList.add('menupos-static');
        (document.querySelector('#nav-ps-pangong') as HTMLElement).style.maxHeight = '100%'; // 100% amit
      }, 500);
    }
  }

  navMobClick() {
    if (this.windowWidth < 992) {
      if (this.navCollapsedMob && !(document.querySelector('app-navigation.pcoded-navbar').classList.contains('mob-open'))) {
        this.navCollapsedMob = !this.navCollapsedMob;
        setTimeout(() => {
          this.navCollapsedMob = !this.navCollapsedMob;
        }, 100);
      } else {
        this.navCollapsedMob = !this.navCollapsedMob;
      }
    }
  }
  
  ngAfterViewInit() {
    Feather.replace();
    if (this.observedDiagram) return;
    this.observedDiagram = this.myDiagramComponent.diagram;
    this.cdr.detectChanges(); // IMPORTANT: without this, Angular will throw ExpressionChangedAfterItHasBeenCheckedError (dev mode only)

    const appComp: AdminComponent = this;
    // listener for inspector
    this.myDiagramComponent.diagram.addDiagramListener('ChangedSelection', function(e) {
      if (e.diagram.selection.count === 0) {
        appComp.selectedNode = null;
      }
      const node = e.diagram.selection.first();
      if (node instanceof go.Node) {
        appComp.selectedNode = node;
      } else {
        appComp.selectedNode = null;
      }
    });
  }

  addNew(newElemFormData){
    var t: string = newElemFormData['newElemTitle'];
    var u: string = newElemFormData['newElemImage'];
    
    var newElem = {
      elemName: t,
      elem: u
    }
    this.http.post('http://127.0.0.1:8000/savedetails',newElem).subscribe(
      (response) => console.log(response),
      (error) => console.log(error)
    )
    this.paletteNodeData.push(newElem)
  }

  sendCanvas(){
    console.log("Send canvas working")
    var state = {
      nodes: this.myDiagramComponent.diagram.model.nodeDataArray,
      links: this.diagramLinkData
    }
    this.http.post('http://127.0.0.1:8000/savecanvas',state).subscribe(
      (response) => console.log(response),
      (error) => console.log(error)
    )

  }

  // ********* INSPECTOR **********
  public handleInspectorChange(newNodeData) {
    const key = newNodeData.key;
    // find the entry in nodeDataArray with this key, replace it with newNodeData
    let index = null;
    for (let i = 0; i < this.diagramNodeData.length; i++) {
      const entry = this.diagramNodeData[i];
      if (entry.key && entry.key === key) {
        index = i;
      }
    }

    if (index >= 0) {
      // here, we set skipsDiagramUpdate to false, since GoJS does not yet have this update
      this.skipsDiagramUpdate = false;
      this.diagramNodeData[index] = _.cloneDeep(newNodeData);
    }
  }

}